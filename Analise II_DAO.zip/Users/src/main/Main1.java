package main;

import model.User;
import daoUsers.UserDAO;
import daoUsers.UserDAOImpl;

public class Main1 {
    public static void main(String[] args) {
        UserDAO userDAO = new UserDAOImpl();

        // Listar todos os usuários
        System.out.println("Todos os usuários:");
        for (User user : userDAO.getAllUsers()) {
            System.out.println(user);
        }

        // Adicionar um novo usuário
        User newUser = new User(3, "Usuario inserido", "emailNovo@3.com");
        userDAO.addUser(newUser);

        // Obter um usuário pelo ID
        User user = userDAO.getUser(3);
        System.out.println("\nUsuário obtido pelo ID:");
        System.out.println(user);

        // Atualizar um usuário
        user.setEmail("emailNovo@4.com");
        userDAO.updateUser(user);
        System.out.println("\nUsuário atualizado:");
        System.out.println(userDAO.getUser(3));

        // Deletar um usuário
        userDAO.deleteUser(1);
        System.out.println("\nTodos os usuários após deletar o ID 1:");
        for (User u : userDAO.getAllUsers()) {
            System.out.println(u);
        }
    }
}

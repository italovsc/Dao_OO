package daoUsers;

import java.util.ArrayList;
import java.util.List;

import model.User;

public class UserDAOImpl implements UserDAO {
    private List<User> users;

    public UserDAOImpl() {
        users = new ArrayList<>();
        // Adicionando usuários de exemplo
        users.add(new User(1, "Usuario 1", "emailDeExemplo@1.com"));
        users.add(new User(2, "Usuario 2", "emailDeExemplo@2.com"));
    }

    @Override
    public void addUser(User user) {
        users.add(user);
    }

    @Override
    public User getUser(int id) {
        for (User user : users) {
            if (user.getId() == id) {
                return user;
            }
        }
        return null;
    }

    @Override
    public List<User> getAllUsers() {
        return users;
    }

    @Override
    public void updateUser(User user) {
        for (int i = 0; i < users.size(); i++) {
            if (users.get(i).getId() == user.getId()) {
                users.set(i, user);
                return;
            }
        }
    }

    @Override
    public void deleteUser(int id) {
        users.removeIf(user -> user.getId() == id);
    }
}

/**
 * 
 */
/**
 * @author italo
 *
 */
module ProductManagement {
	requires java.sql;
}
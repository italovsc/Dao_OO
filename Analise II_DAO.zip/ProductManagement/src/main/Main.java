package main;

import dao.ProductDao;
import dao.ProductDaoImpl;
import model.Product;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static final ProductDao productDao = new ProductDaoImpl();
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("Bem-vindo ao sistema de gerenciamento de produtos!");

        while (true) {
            System.out.println("\nSelecione uma opção:");
            System.out.println("1. Adicionar produto");
            System.out.println("2. Atualizar produto");
            System.out.println("3. Listar todos os produtos");
            System.out.println("4. Deletar produto");
            System.out.println("5. Sair");

            int choice = getUserChoice();

            switch (choice) {
                case 1:
                    addProduct();
                    break;
                case 2:
                    updateProduct();
                    break;
                case 3:
                    listAllProducts();
                    break;
                case 4:
                    deleteProduct();
                    break;
                case 5:
                    System.out.println("Saindo do programa...");
                    return;
                default:
                    System.out.println("Opção inválida. Por favor, selecione novamente.");
            }
        }
    }

    private static int getUserChoice() {
        int choice = 0;
        boolean validInput = false;
        while (!validInput) {
            try {
                System.out.print("Opção: ");
                choice = scanner.nextInt();
                validInput = true;
            } catch (InputMismatchException e) {
                System.out.println("Por favor, insira um número correspondente à opção desejada.");
                scanner.next(); // Limpa o buffer do scanner
            }
        }
        return choice;
    }

    private static void addProduct() {
        System.out.print("\nDigite o nome do produto: ");
        String name = scanner.next();

        System.out.print("Digite o preço do produto: ");
        double price = scanner.nextDouble();

        Product newProduct = new Product(0, name, price);
        int id = productDao.addProduct(newProduct);
        System.out.println("Produto adicionado com ID " + id);
    }

    private static void updateProduct() {
        System.out.print("\nDigite o ID do produto que deseja atualizar: ");
        int id = scanner.nextInt();

        Product existingProduct = productDao.getProduct(id);
        if (existingProduct == null) {
            System.out.println("Produto com ID " + id + " não encontrado.");
            return;
        }

        System.out.print("Novo nome (deixe em branco para manter o mesmo): ");
        String newName = scanner.next();
        if (!newName.isEmpty()) {
            existingProduct.setName(newName);
        }

        System.out.print("Novo preço (deixe 0.0 para manter o mesmo): ");
        double newPrice = scanner.nextDouble();
        if (newPrice != 0.0) {
            existingProduct.setPrice(newPrice);
        }

        productDao.updateProduct(existingProduct);
        System.out.println("Produto atualizado com sucesso.");
    }

    private static void listAllProducts() {
        List<Product> products = productDao.getAllProducts();
        if (products.isEmpty()) {
            System.out.println("Nenhum produto encontrado.");
        } else {
            System.out.println("\nLista de produtos:");
            for (Product product : products) {
                System.out.println(product);
            }
        }
    }

    private static void deleteProduct() {
        System.out.print("\nDigite o ID do produto que deseja deletar: ");
        int id = scanner.nextInt();

        Product existingProduct = productDao.getProduct(id);
        if (existingProduct == null) {
            System.out.println("Produto com ID " + id + " não encontrado.");
            return;
        }

        productDao.deleteProduct(id);
        System.out.println("Produto deletado com sucesso.");
    }
}
